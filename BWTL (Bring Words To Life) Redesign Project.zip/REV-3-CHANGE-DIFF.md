# BWTL REV-3 — Change Diff (build)

This is the **as-built** diff for the IA consolidation. Companion to `REV-3-SPEC.md` (the design spec). Read this to understand exactly what changed in the code between the REV-2 bundle and this REV-3 bundle.

---

## One-paragraph summary

Three top-level destinations collapsed into one. **Library → renamed Browse and promoted to the home/default route.** **Study** and **Bookmarks** are gone as destinations — Study became a filter (*Bookmarked = study set*), and Bookmarks became a per-tab filter. The card detail is now the open-state of a Browse row (click to enter), and its **prev/next walks the active filter+sort spine**. Pronunciation and Shadowing became **mode tabs on the card** (legacy Super Flashcards pattern). The **Chat** tab slimmed to *Threads + Audit log*; *New cards* moved to a "+ New" action on Browse, *Batch jobs* moved to Admin.

**Final nav:** `Browse · Generate · Chat · Admin · Settings`

---

## Before → After

### Navigation
```
BEFORE (REV-2):  Study · Library · Generate · Bookmarks · Chat · Admin · Settings   (7)
AFTER  (REV-3):  Browse · Generate · Chat · Admin · Settings                        (5)
```

### Where things went
| REV-2 location | REV-3 location |
|----------------|----------------|
| Study › Today's queue | Browse › sort "SRS due" (optional) |
| Study › Word study (card) | Browse › click a card → **Card detail** |
| Study › Pronunciation | Card detail › **Pronunciation** mode tab |
| Study › Shadowing | Card detail › **Shadowing** mode tab |
| Library | **Browse** (renamed, now home) |
| Bookmarks (destination) | **"Bookmarked" filter** on Browse tabs · *bookmark = study set* |
| Chat › New cards | Browse › **"+ New"** button |
| Chat › Batch jobs | **Admin › Batch jobs** |
| Chat › Threads, Audit log | Chat › Threads, Audit log *(unchanged)* |

---

## File-by-file diff

### `src/app.jsx` — routing rewrite
- `section` default changed `'study'` → **`'browse'`**.
- **Removed** the `study`, `library`, and `bookmarks` route branches; removed the Study sub-nav strip and the topbar bookmark-rail button + REV-2 topbar card-nav cluster.
- **Added** `cardFilter` state `{ chips[], language, sort, q }` (single source of truth — absorbed the REV-2 `langFilter`).
- **Added** `detailCardId` / `detailMode` state. Card detail renders when `detailCardId` is set under the `browse` section.
- **Added** `computeCardSpine(cardFilter)` — the ordered, filtered card-id list that drives BOTH the Browse grid and the detail prev/next.
- `navigateWord` is now `openCard` (unified) → sets `detailCardId`. `navByDelta` walks `cardSpine`. Alt+←/→ active when a detail is open.
- Topbar nav array rebuilt to the 5 destinations; renamed "Library"→"Browse"; brand sub-label → `v0.3 · REV-3`.

### `src/library.jsx` — `LibraryView` → `BrowseView`
- Renamed export to `BrowseView` (kept `window.LibraryView` alias for safety).
- Header title "Library"→"Browse"; **added "+ New"** button (dispatches `bwtl:open-create`).
- **Added `CardFilterBar`**: chips (Study set / Has video / Missing data), Language dropdown, Sort dropdown, live result-count readout.
- `CardsTab` now renders the **App-computed spine** (grid order == nav order) instead of filtering internally; card click → `onOpenCard` (opens detail, not a Study route).
- Card grid uses the REV-2/3 thumbnail (`.browse-thumb`) with word overlay + video/bookmark badges.

### `src/workspace.jsx` — new `CardDetail` wrapper
- **Added `CardDetail`**: sticky header with ‹ Browse back, breadcrumb (Browse / language / word), **Add-to-study bookmark toggle**, and `‹ N / M ›` prev/next; **mode tabs** Study · Pronunciation · Shadowing.
- Study mode renders the existing `Workspace` (full word card + rail + chat dock); Pronunciation/Shadowing render the practice views with the current `card`.
- Exported `window.CardDetail`.

### `src/study-extra.jsx` — modes, not routes
- `PronunciationView` and `ShadowingView` now take a `card` prop and render that word (was hardcoded μνήμη). Headings de-emphasized since they live inside the detail.
- `StudyQueueView` retained in source but no longer routed (dead/unloaded).

### `src/theodoros.jsx` — Chat slimmed
- Tab array reduced to **Threads + Audit log** (removed `new_cards`, `batch`).
- Header copy reframed to "your AI conversations"; removed the "New card" header button.
- Stat row's batch stat now reads "→ now in Admin". `NewCardsTab`/`BatchJobsRedirectTab` remain in source but are no longer rendered.

### `src/data.js` — bookmark kinds
- **Dropped the `collection` bookmark kind** (removed `bm7`); fixed `bm6` thread ref to the re-keyed `th_memoire_1`.

### `src/spec.jsx` — spec doc
- **Added a REV-3 callout** (blue) up top.
- **Rewrote §1 Information architecture** tree to Browse-as-home, with Study/Bookmarks shown as removed and the card-detail modes + per-tab Bookmarked filter documented.

### `index.html`
- Loads `src/etymology.jsx` (REV-2). No structural change in REV-3 beyond the thumbnail/pron-pill CSS already present.

---

## Backend implications (unchanged from REV-3-SPEC.md §7)

- **No new `in_study_set` column** — study set = `flashcards.bookmarked` (bookmark = study set).
- Sort by last-modified wants `flashcards.updated_at` in list responses.
- "Missing data" filter reuses the AI-healable-field coverage flags.
- Per-tab Bookmarked filter → optional `?bookmarked=true` on list endpoints, or client-side against the `bookmarks` table.
- `collection` removed from the polymorphic bookmark set.
- No change to REV-2 etymology / figure / scholarly-notes APIs.

---

## Demo flows to try in the build

1. **Browse → study a word:** land on Browse, click **souvenir** → detail opens with Study mode. Use `‹ ›` (or Alt+←/→) to walk cards.
2. **Modes:** in any open card, switch **Pronunciation** / **Shadowing** — same word, different activity.
3. **Study set:** click the **Study set** chip → grid collapses to bookmarked cards. Open one, hit **Add to study** to toggle membership.
4. **Filter-aware spine:** set Language = French, open a card — prev/next now walks only French cards.
5. **Figure card:** open **Χρόνος** → Origin Story + Family Tree render inline.
6. **Chat:** open the Chat tab → only Threads + Audit log. **Batch jobs** now lives under **Admin**. **+ New** is on Browse.
