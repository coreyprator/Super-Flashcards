# BWTL REV-3 — IA Consolidation: Browse-as-home

Diff spec for the Study→Browse + Bookmarks→Browse fold. Status: **spec only, not yet implemented.** Companion to REV-1 (chat) and REV-2 (etymology surface).

## Decision summary (from design review, May 30 2026)

| # | Decision | Status |
|---|----------|--------|
| 1 | Fold Study into Browse. Study becomes a *filter*, not a destination. | ✅ confirmed |
| 2 | SRS de-emphasized — one optional sort, never the spine. | ✅ confirmed |
| 3 | Card detail = the "open" state of a Browse row, not a top-level section. | ✅ confirmed |
| 4 | Prev/next navigation walks the **active filter+sort set**. | ✅ confirmed |
| 5 | Pronunciation + Shadowing fold into the card detail as **modes/tabs on the card** (legacy Super Flashcards pattern). | ✅ confirmed |
| 6 | Rename **Library → Browse**. | ✅ confirmed |
| 7 | Fold **Bookmarks into Browse** as a per-tab filter. Bookmarks stops being a top-level destination. | ✅ confirmed |
| 8 | **Bookmark = study set.** One concept. Bookmarking a card adds it to your study set. | ✅ confirmed — dissolves the old §5 "study set" question |
| 9 | Home for non-card bookmark kinds (collections dropped; threads → Chat filter). | ✅ resolved — see §5 |
| 10 | Chat tab becomes **purely conversational**: keep Threads + Audit log. Move **New cards → a "+ New" action on Browse**; move **Batch jobs → Admin**. | ✅ confirmed |

---

## 1 · Information architecture — DIFF

```
  BWTL — unified shell
- ├─ Study                         [REMOVE as top-level destination]
- │  ├─ Today's queue              (SRS-driven)
- │  ├─ Word study                 → becomes the card-detail view (§3)
- │  ├─ Pronunciation              → becomes a card-detail mode (§4)
- │  └─ Shadowing                  → becomes a card-detail mode (§4)
  │
- ├─ Bookmarks                     [REMOVE as top-level destination]
- │  └─ words/roots/figures/...    → becomes a "Bookmarked" filter per Browse tab (§2)
  │
~ ├─ Browse  (was "Library")       [PROMOTE to front door / default route]
  │  ├─ Cards     (SF)             [MODIFY — gains filter+sort bar §2]
+ │  │  └─ ▸ open card → Card Detail view (§3) with mode tabs (§4)
+ │  ├─ + New                      [ADD — was Chat / "New cards"; single-card + doc import]
  │  ├─ PIE roots (EFG)
  │  ├─ Figures   (EM)
  │  ├─ Beekes    (RAG)
  │  └─ DCC
+ │  (every entity-tab gains a "Bookmarked" filter chip)
  │
  ├─ Chat                          [MODIFY — now purely conversational]
  │  ├─ Threads                    (cross-app thread index; gains Bookmarked filter)
  │  ├─ Audit log                  (chat_promotions — every Accept)
- │  ├─ New cards                  → MOVED to Browse / "+ New"
- │  └─ Batch jobs                 → MOVED to Admin
  │
  ├─ Generate · Admin · Settings   [Admin gains the Batch jobs tab]
```

**Top-nav order becomes:** `Browse · Generate · Chat · [Admin] · Settings`
**Default landing route:** `Browse / Cards` (was `Study / Word study`).

Two destinations removed (`Study`, `Bookmarks`); nav drops from 6–7 items to 4–5.
Chat slims to Threads + Audit log; authoring/ops move to where they belong
(Browse for creation, Admin for batch).

---

## 2 · Browse Cards tab — ADD filter + sort bar

A new control bar above the card grid. Drives both the grid AND the detail-view prev/next spine.

```
ADD  FilterBar:
       Filter chips (multi-select where sensible):
         • All                  (default)
         • Bookmarked ★         (= your study set — §5; bookmarking adds here)
         • Language ▾           (Greek / French / English / … — single-select dropdown)
         • Has video
         • Missing data         (any AI-healable field empty — reuses health flags)
       Sort dropdown (single-select):
         • Last modified  (default)
         • Alphabetical
         • SRS due        (optional; surfaced only when wanted, never forced)
         • Frequency      (DCC rank, Greek only)
       Result count + "active spine" readout:
         e.g. "12 cards · Bookmarked · French · sorted by last modified"
```

Note: the old separate "Study set" and "Bookmarked" chips are now **one** chip
(Decision 8). The ★ Bookmarked filter IS the study-set filter.

**State shape (new, lifted to App):**
```js
cardFilter = {
  chips: Set<'bookmarked'|'has_video'|'missing_data'>,
  language: string | null,     // supersedes REV-2 langFilter — merge the two
  sort: 'modified'|'alpha'|'srs'|'freq',
}
```
Replaces/absorbs the REV-2 `langFilter` topbar state — they become one source of truth.

The **Bookmarked filter is available on every Browse tab** (Cards, PIE roots,
Figures), which is how the old polymorphic Bookmarks destination is preserved —
it's now "filter this dataset to what I've saved" rather than a separate page.

---

## 3 · Card Detail view — MODIFY (was "Study / Word study")

No longer a route; it's the open-state of a Browse row. Reached by clicking a card.

```
MODIFY  <Workspace> → render as an overlay/route-detail opened FROM Browse.
ADD     Detail header gains:
          • "‹ Back to Browse" — returns to the grid with filter+sort intact
          • Breadcrumb: Browse / {language} / {word}
          • Prev/Next ‹ N / M › — walks cardFilter's ordered result set (§4-spine)
          • ★ Bookmark toggle — adds/removes from study set (Decision 8)
KEEP    Everything from REV-2: hero, IPA+anglicized pills, multi-root PIE,
        etymology, origin story + family tree (figures), cognates, fun facts,
        scholarly notes, right rail (PIE Explorer / EFG / EM / RAG / ArtForge),
        chat dock.
```

**Prev/next spine (the key interaction):** the detail view receives the ordered
`cardFilter` result list at open time. `‹`/`›` and `Alt+←/→` step through *that*
list — change nothing about the filter and the spine is stable; change the filter
(only possible after going Back) and the spine reshapes. Wrap-around at ends.

---

## 4 · Card-detail MODE TABS — ADD (legacy Super Flashcards pattern)

A tab strip at the top of the card detail. Default = **Study** (the full info card).

```
ADD  ModeTabs on card detail:
       • Study          [default]  — the full word card (everything REV-2)
       • Pronunciation             — IPA/anglicized drill, audio compare,
                                      record-yourself, minimal-pair practice
       • Shadowing                 — sentence-level audio + your-voice overlay,
                                      waveform align (uses VOICE_CLONES data)
     Tabs are per-card; switching mode keeps the same word + prev/next spine.
```

These were standalone Study sub-tabs in REV-1/2 (`PronunciationView`, `ShadowingView`
in `study-extra.jsx`). MODIFY them to accept a `card` prop and render inside the
detail shell instead of as full-page routes. Their existing internals are reusable.

---

## 5 · Bookmark = study set · and the non-card bookmark kinds

**Resolved (Decision 8):** the old "study set" question is gone. Bookmarking a card
IS adding it to the study set. Reuses the existing `flashcards.bookmarked` bool and
the polymorphic `bookmarks` table — **no new `in_study_set` column**. SRS-due
survives only as an optional *sort*, never the spine.

**Open item — the other bookmark kinds.** The polymorphic bookmark covers 5 kinds:
`word · pie_root · figure · thread · collection`. Folding Bookmarks into Browse
handles the first three cleanly (Bookmarked filter on each entity tab). The last two
need a home:

| Kind | Proposed home | Notes |
|------|---------------|-------|
| `word` | Browse / Cards · Bookmarked filter | = study set |
| `pie_root` | Browse / PIE roots · Bookmarked filter | ✓ |
| `figure` | Browse / Figures · Bookmarked filter | ✓ |
| `thread` | **Chat tab · Bookmarked filter** | threads already live in Chat (REV-1); add a saved filter there |
| `collection` | **DROPPED** | per review — PL doesn't use collections; remove the kind entirely |

**Resolved:** thread-bookmarks → a Bookmarked filter in the Chat tab. Collections
are dropped (the `collection` bookmark kind is removed from the polymorphic set;
no Collections tab).

---

## 6 · Component-level diff

| File | Change |
|------|--------|
| `src/app.jsx` | REMOVE `section==='study'` branch + Study sub-nav. REMOVE `section==='bookmarks'`. PROMOTE `browse` to default `section`. RENAME nav label Library→Browse. ADD `cardFilter` state + `detailOpen`/`detailCardId`. MODIFY prev/next to walk `cardFilter` result set. Merge REV-2 `langFilter` into `cardFilter.language`. ADD a "+ New" action in the Browse header (opens the existing `NewCardSheet`). |
| `src/library.jsx` | RENAME export → `BrowseView` (keep `LibraryView` alias for safety). ADD `FilterBar` to `CardsTab` + per-tab Bookmarked filter. Card click → open detail (not navigate-to-Study). Compute + expose the ordered result set as the nav spine. ADD "+ New" entry point. |
| `src/bookmarks.jsx` | DEPRECATE `BookmarksView` as a route. Salvage its bookmark-row rendering into the Bookmarked-filter results. |
| `src/workspace.jsx` | MODIFY `Workspace` → detail view opened from Browse: Back affordance, breadcrumb, ★ bookmark toggle, mode tabs. |
| `src/study-extra.jsx` | MODIFY `PronunciationView` / `ShadowingView` to take a `card` prop + render as detail modes, not routes. |
| `src/theodoros.jsx` (Chat tab) | REMOVE the `new_cards` and `batch` sub-tabs. Chat keeps only **Threads** (+ Bookmarked filter, home for thread-bookmarks §5) and **Audit log**. |
| `src/admin.jsx` | The `batch` tab already exists here — ensure it's the single home for Batch jobs now that Chat's copy is removed. No new code, just the canonical location. |
| `src/chat.jsx` | ADD a Bookmarked filter to the threads index. |
| `src/spec.jsx` | ADD §1 IA rewrite + REV-3 callout. Update screen table. Rename Library→Browse, drop Bookmarks destination, slim Chat to 2 sub-tabs. |
| `src/data.js` | No new `in_study_set` column (Decision 8 reuses `bookmarked`). Remove `collection` from the bookmark kind set (Decision 9). |
| topbar | REV-2 universal FTS search stays; card result opens detail. Language filter in search box now reads/writes `cardFilter.language` (single source of truth). |

---

## 7 · Backend implications

- **No new `in_study_set` column** — study set = `flashcards.bookmarked` (Decision 8). The polymorphic `bookmarks` table is unchanged and now powers the per-tab Bookmarked filters.
- **Sort by last-modified** needs `flashcards.updated_at` exposed in list responses (likely already exists).
- **"Missing data" filter** reuses the 16 AI-healable-field coverage flags already computed for the health dashboard — expose a per-card `has_missing_fields` bool or compute client-side.
- **Bookmarked filter per dataset** — list endpoints (`/api/flashcards`, EFG nodes, EM figures) gain an optional `?bookmarked=true` param, or filter client-side against the `bookmarks` table.
- No change to the etymology/figure/scholarly-notes APIs from REV-2.
- SRS endpoints (`/api/study/*`) are no longer the navigation driver but stay available for the optional SRS-due sort.

---

## 8 · What this resolves

- Kills the Study/Library redundancy **and** the Bookmarks redundancy — one browse surface, one detail view, filters instead of destinations.
- SRS becomes opt-in (a sort), not the spine.
- Bookmark = study set: one gesture, one concept, no parallel "saved" vs "studying" lists.
- Detail prev/next finally has a coherent answer to "next *within what?*" — the active filter.
- Pronunciation/Shadowing return to their natural home: on the word (legacy SF parity).
- Chat is purely conversational (Threads + Audit log); authoring lives on Browse, batch ops live in Admin.
- Top nav simplifies to **Browse · Generate · Chat · [Admin] · Settings**.

**Before I build:** confirm §5 (thread-bookmarks → Chat filter; collections → small Browse tab — or drop collections entirely?).
